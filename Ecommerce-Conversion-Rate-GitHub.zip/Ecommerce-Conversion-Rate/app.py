from flask import Flask, render_template, jsonify
import csv
from pathlib import Path

app = Flask(__name__)
DATA_FILE = Path("data/ecommerce_data.csv")

def load_data():
    rows=[]
    with DATA_FILE.open(newline="",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            row["visitors"]=int(row["visitors"])
            row["orders"]=int(row["orders"])
            row["revenue"]=float(row["revenue"])
            rows.append(row)
    return rows

@app.route("/")
def dashboard():
    data=load_data()
    visitors=sum(r["visitors"] for r in data)
    orders=sum(r["orders"] for r in data)
    revenue=sum(r["revenue"] for r in data)
    rate=orders/visitors*100 if visitors else 0
    return render_template("index.html",data=data,visitors=visitors,orders=orders,revenue=revenue,rate=rate)

@app.route("/api/data")
def api_data():
    return jsonify(load_data())

if __name__=="__main__":
    app.run(debug=True)
