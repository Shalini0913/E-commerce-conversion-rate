# E-Commerce Conversion Rate Analysis

A Python and Flask web dashboard for analyzing e-commerce visitors, orders, revenue and conversion rate.

## Features
- Total visitors, orders and revenue
- Overall and monthly conversion rate
- Visitors vs orders bar chart
- Conversion-rate line chart
- CSV sample dataset
- Responsive web dashboard

## Technology
Python, Flask, HTML, CSS, JavaScript, Chart.js and CSV.

## Run
Install Python 3.9+ and run:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Formula
Conversion Rate = (Orders / Visitors) × 100

## Dataset
Edit `data/ecommerce_data.csv` using columns:
`month,visitors,orders,revenue`

The included values are sample data for academic demonstration and are not live store data.
